require 'open-uri'

class HomeController < ApplicationController
  def index

    # Get data and time
    time = Time.new
    @CurrentTime = time.inspect
 
    # Get hostanme
    @Hostname = request.host

    # Get instance id from EC2 metadata service
    @EC2Instance = open('http://169.254.169.254/latest/meta-data/instance-id').read

    # Get the database we are connected to
    @MySQL = "localhost"
    @MySQL = "#{Rails.configuration.database_configuration[Rails.env]["host"]}:#{Rails.configuration.database_configuration[Rails.env]["port"]}" if Rails.configuration.database_configuration[Rails.env]["host"]
    @Database = Rails.configuration.database_configuration[Rails.env]["database"]

  end
end

