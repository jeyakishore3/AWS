# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Sample::Application.config.secret_token = '84ae689d69f2441dc4056bc370ff734f257a0ae7ea3dd3f1765e99bdf777ae1ac5ea3a1c3e6a5cd499b139d53ca83051290fc2e3487ef2ab3215e70332a9ef3a'
