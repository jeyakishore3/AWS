# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CloudFormer::Application.config.secret_token = '1c072ad5d57cc5b467cbd73123743cdd7a718d0552d45822a516d6c2737e945271f1dd8c183d28860c60a0e78610f46d84bef10d947ca08e16e265638b9f10cf'
