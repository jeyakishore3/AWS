class Enis < CF_converter

  attr_accessor :name
  
  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)
    begin
      # Get all the network interface resources we care about
      ec2 = AWS::EC2.new(:region => region)
      # Remove all RDS and ELB ENIs
      enis = []
      ec2.client.describe_network_interfaces().data[:network_interface_set].each do |eni|
        if (!eni[:requester_managed])
          eni.delete(:attachment)
          enis.push(eni)
        end
      end
      # Remove all instance attached ENIs
      all_enis = []
      enis.each do |eni|
        all_enis.push(eni) if eni[:status] && eni[:status] != "in-use"
      end
      all_resources.merge!({:enis => all_enis})
    rescue => e
      all_errors.merge!({:enis => e.message})
      all_resources.merge!({:enis => {}})
    end
  end
  
  def self.ResourceName(resource)
    return resource[:network_interface_id].tr('^A-Za-z0-9', '')
  end
  
  def self.get_dependencies(resource, all_resources)
    return {}
  end
  
  def self.get_resource_attributes(resource)
    tags = ""
    if resource[:tag_set]
      resource[:tag_set].each do |tag|
        tags = tags + "\n" + "#{tag[:key]}: #{tag[:value]} " if tag[:value] != nil
      end
    end          
    return "NetworkInterfaceId: #{resource[:network_interface_id]} \n" +
           "Description: #{resource[:description]} \n" +
           "VPCId: #{resource[:vpc_id]} \n" +
           "SubnetId: #{resource[:subnet_id]} " +
           tags
  end

  def self.OutputList(resource)
    return {"Elastic Network Interface Id" => "ENI,Ref"}
  end

  def initialize(resource)
    @name = Enis.ResourceName(resource)
    super(@name, "AWS::EC2::NetworkInterface")
  end
  
  def convert(resource, template, name_mappings)
    props = {}
    props.merge!({"Description" => resource[:description]}) if resource[:description]
    props.merge!({"PrivateIpAddress" => resource[:private_ip_address]}) if resource[:private_ip_address]
    props.merge!({"SourceDestCheck" => resource[:source_dest_check]}) if resource[:source_dest_check]
    props.merge!({"SubnetId" => ref_or_literal(:subnets, resource[:subnet_id], template, name_mappings)}) if resource[:subnet_id]

    if resource[:groups]
      groups = []
      resource[:groups].each do |group|
        if group[:group_id]
          groups.push(ref_or_literal(:security_groups, group[:group_id], template, name_mappings))
        end
      end
      props.merge!({"GroupSet" => groups}) if groups != []
    end

    if resource[:tag_set]
      tags = []
      if resource[:tag_set]
        resource[:tag_set].each do |tag|
          tags.push({"Key" => tag[:key], "Value" => tag[:value]}) if tag[:value] != nil and !tag[:key].starts_with?("aws:")
        end
      end          
      props.merge!({"Tags" => tags}) if !tags.empty?      
    end

    return @cf_definition.deep_merge({ Enis.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props }})
  end
    
end
