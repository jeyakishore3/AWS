class Queue_Policies < CF_converter
  
  attr_accessor :name

  @@policy_id = 1
  
  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)

    begin
      # Get all the SQS queues we care about
      sqs = AWS::SQS.new(:region => region)
      queue_policies = []
      sqs.queues.each do |queue|
        policy = []
        queue.policy.statements.each do |statement|
          new_statement = {}
          new_statement.merge!({"Action" => statement.actions}) if statement.actions
          #new_statement.merge!({"Conditions" => statement.conditions}) if statement.conditions
          new_statement.merge!({"Effect" => statement.effect}) if statement.effect
          new_statement.merge!({"Excluded_Action" => statement.excluded_actions}) if statement.excluded_actions
          new_statement.merge!({"Principal" => { "AWS" => statement.principals}}) if statement.principals
          new_statement.merge!({"Resource" => statement.resources}) if statement.resources
          new_statement.merge!({"Sid" => statement.sid}) if statement.sid
          if (!new_statement["Sid"] || (new_statement["Sid"] && !new_statement["Sid"].include?('__default_statement_ID')))
            policy.push(new_statement)
          end
        end if queue.policy
        nameparts = queue.url.split("/")
        queue_policies << {:name => nameparts.last, :display_name => "Queue policy for #{nameparts.last}", :policy => policy} if !policy.empty?
      end
      all_resources.merge!({:queue_policies => queue_policies})
    rescue => e
      all_errors.merge!({:queue_policies => e.message})
      all_resources.merge!({:queue_policies => {}})
    end
  end

  def self.ResourceName(resource)
    return "sqspolicy" + resource[:name].tr('^A-Za-z0-9', '') 
  end

  def initialize(resource)
    @name = Queue_Policies.ResourceName(resource)
    super(@name, "AWS::SQS::QueuePolicy")
  end
  
  def convert(resource, template, name_mappings)
    props = {}
    props.merge!({"Queues" => [ref_or_literal(:queues, resource[:name], template, name_mappings)]}) if resource[:name]
    if resource[:policy]
      resource[:policy].each do |statement|
        newres = []
        statement["Resource"].each do |res|
          newres << ref_or_getatt(:queues, res, :queue_arn, "Arn", template, name_mappings)
        end
        statement["Resource"] = newres
      end
      props.merge!({"PolicyDocument" => {"Statement" => resource[:policy]}})
    end
    return @cf_definition.deep_merge({ Queue_Policies.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props }})
  end
    
end
