class EIP_Associations < CF_converter
  
  attr_accessor :name
  @@association_id = 1

  def self.post_selection(template)
    candidates = []
    props = []
    if template.all_resources && template.all_resources[:eips]
      template.all_resources[:eips].each do |eip|
        candidates.push(eip[:public_ip])
      end
    end
    if template.selected_resources && template.selected_resources[:eips]
      template.selected_resources[:eips].each do |eip|
        candidates.reject!{|cand| cand == eip[:public_ip]}
      end
    end
    if template.selected_resources && template.selected_resources[:instances]
      template.selected_resources[:instances].each do |instance|
        if candidates.index(instance[:ip_address])
          props << {:name=>"assoc#{@@association_id}", :instance_id => instance[:instance_id], :public_ip => instance[:ip_address]}
          @@association_id = @@association_id + 1
        end
      end
    end
    template.selected_resources.merge!({:eipassociations => props})
  end

  def initialize(resource)
    @name = resource[:name]
    super(@name, "AWS::EC2::EIPAssociation")
  end
  
  def convert(resource, template, name_mappings)
    props = {}
    props.merge!({"AllocationId" => resource[:allocation_id]}) if resource[:allocation_id]
    props.merge!({"NetworkInterfaceId" => ref_or_literal(:enis, resource[:network_interface_id], template, name_mappings)}) if resource[:network_interface_id] 
    props.merge!({"InstanceId" => ref_or_literal(:instances, resource[:instance_id], template, name_mappings)}) if resource[:instance_id] 
    props.merge!({"EIP" => ref_or_literal(:eips, resource[:public_ip], template, name_mappings)}) if resource[:public_ip]
    return @cf_definition.deep_merge({ EIP_Associations.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props }})
  end
    
end
