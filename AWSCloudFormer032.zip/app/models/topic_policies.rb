class Topic_Policies < CF_converter
  
  attr_accessor :name

  @@policy_id = 1
  
  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)

    begin
      # Get all the SNS topics we care about
      sns = AWS::SNS.new(:region => region)
      topic_policies = []
      sns.topics.each do |topic|
        policy = []
        topic.policy.statements.each do |statement|
          new_statement = {}
          new_statement.merge!({"Action" => statement.actions}) if statement.actions
          #new_statement.merge!({"Conditions" => statement.conditions}) if statement.conditions
          new_statement.merge!({"Effect" => statement.effect}) if statement.effect
          new_statement.merge!({"Excluded_Action" => statement.excluded_actions}) if statement.excluded_actions
          new_statement.merge!({"Principal" => { "AWS" => statement.principals}}) if statement.principals
          new_statement.merge!({"Resource" => statement.resources}) if statement.resources
          new_statement.merge!({"Sid" => statement.sid}) if statement.sid
          if (!new_statement["Sid"] || (new_statement["Sid"] && !new_statement["Sid"].include?('__default_statement_ID')))
            policy.push(new_statement)
          end
        end
        # in order to find the account id for the ARN, find an EC2 security group in the account
        ec2 = AWS::EC2::new(:region => region)
        owner_id = ec2.security_groups.first.owner_id
        topic_policies << {:name => topic.display_name, :display_name => "Topic policy for #{topic.display_name}", :arn => topic.name, :region => region, :owner_id => owner_id, :policy => policy} if !policy.empty?
      end
      all_resources.merge!({:topic_policies => topic_policies})
    rescue => e
      all_errors.merge!({:topic_policies => e.message})
      all_resources.merge!({:topic_policies => {}})
    end
  end

  def self.ResourceName(resource)
    return "snspolicy" + resource[:name].tr('^A-Za-z0-9', '') 
  end

  def initialize(resource)
    @name = Topic_Policies.ResourceName(resource)
    super(@name, "AWS::SNS::TopicPolicy")
  end
  
  def convert(resource, template, name_mappings)
    props = {}
    topic_name = ref_or_literal(:topics, resource[:name], template, name_mappings)
    props.merge!({"Topics" => [topic_name]})
    if resource[:policy]
      resource[:policy].each do |statement|
        newres = []
        statement["Resource"].each do |res|
          if topic_name.class == String
            newres << "arn:aws:sns:#{resource[:region]}:#{resource[:owner_id]}:#{resource[:arn]}"
          else
            newres << topic_name
          end
        end
        statement["Resource"] = newres
      end
      props.merge!({"PolicyDocument" => {"Statement" => resource[:policy]}})
    end
    return @cf_definition.deep_merge({ Topic_Policies.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props }})
  end
    
end
