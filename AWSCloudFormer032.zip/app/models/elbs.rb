class Elbs < CF_converter
  
  attr_accessor :name

  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)
    begin
      # Get all the Load Balancers we care about
      elb = AWS::ELB.new(:region => region)
      lbs = []
      elb.client.describe_load_balancers().data[:load_balancer_descriptions].each do |lb|
        full_lb = lb.clone
        full_lb.reject!{ |k| k == :created_time }
        lbs << full_lb
      end
      all_resources.merge!({:elbs => lbs})
    rescue => e
      all_errors.merge!({:elbs => e.message})
      all_resources.merge!({:elbs => {}})
    end
  end

  def self.ResourceName(resource)
    return "elb" + resource[:load_balancer_name].tr('^A-Za-z0-9', '')
  end
  
  def self.get_dependencies(resource, all_resources)
    retInstances = []
    if all_resources[:instances]
      all_resources[:instances].each do |instance|
        resource[:instances].each do |lb_instance|
          retInstances.push(instance) if lb_instance[:instance_id] == instance[:instance_id]
        end if resource[:instances]
      end      
    end

    retASGs = []
    if all_resources[:as_groups]
      all_resources[:as_groups].each do |asg|
        retASGs.push(asg) if asg[:load_balancer_names].include?(resource[:load_balancer_name])
      end      
    end

    sgResources = []
    if all_resources[:security_groups]
      all_resources[:security_groups].each do |sg|
        sgResources.push(sg) if resource[:security_groups].include?(sg[:group_id])
      end      
    end

    return { :instances => retInstances, :as_groups => retASGs, :security_groups => sgResources }
  end

  def self.get_resource_attributes(resource)
    tags = ""
    if resource[:tags]
      resource[:tags].each do |key, value|
        tags = tags + "\n" "#{key}: #{value} "
      end
    end          

    return "DNS Name: #{resource[:dns_name]} \n" +
           "Availability Zones: #{resource[:availability_zones]} " + tags
  end
  
  def self.OutputList(resource)
    return {"Load Balancer Name" => "Name,Ref",
            "DNS Name" => "DNS,GetAtt,DNSName",
            "Endpoint URL" => "URL,Join,,http://,GetAtt,DNSName"
           }
  end

  def initialize(resource)
    @name = Elbs.ResourceName(resource)
    super(@name, "AWS::ElasticLoadBalancing::LoadBalancer")
  end
  
  def convert(resource, template, name_mappings)

    in_vpc = resource[:subnets] && resource[:subnets].any?
    props = {}
    props.merge!({"AvailabilityZones" => resource[:availability_zones]}) if resource[:availability_zones] && !resource[:availability_zones].empty? && !in_vpc
    props.merge!({"Scheme" => resource[:scheme]}) if resource[:scheme] && resource[:scheme] == "internal"

    if resource[:subnets]
      subnets = []
      resource[:subnets].each do |subnet|
        subnets.push(ref_or_literal(:subnets, subnet, template, name_mappings))
      end
      props.merge!({"Subnets" => subnets}) if !subnets.empty?
    end

    if resource[:health_check] && !resource[:health_check].empty? 
      props.merge!({"HealthCheck" => {
        "HealthyThreshold"   => resource[:health_check][:healthy_threshold].to_s,
        "Interval"           => resource[:health_check][:interval].to_s,
        "Target"             => resource[:health_check][:target].to_s,
        "Timeout"            => resource[:health_check][:timeout].to_s,
        "UnhealthyThreshold" => resource[:health_check][:unhealthy_threshold].to_s
      }})
    end
    
    if resource[:instances]
      instances = []
      resource[:instances].each do |instance|
        exists = false
        template.all_resources[:instances].each do |all|
          exists = exists || (all[:instance_id] == instance[:instance_id])
        end
        instances.push(ref_or_literal(:instances, instance[:instance_id], template, name_mappings)) if exists    
      end
      props.merge!({"Instances" => instances}) if !instances.empty?      
    end
    
    if resource[:security_groups]
      groups = []
      resource[:security_groups].each do |group|
        groups.push(ref_or_literal(:security_groups, group, template, name_mappings))        
      end
      props.merge!({"SecurityGroups" => groups}) if !groups.empty?
    end

    if resource[:listener_descriptions]
      listeners = []
      resource[:listener_descriptions].each do |listener|
        lprops = {};
        lprops.merge!({"InstancePort"     => listener[:listener][:instance_port].to_s})
        lprops.merge!({"LoadBalancerPort" => listener[:listener][:load_balancer_port].to_s})
        lprops.merge!({"Protocol"         => listener[:listener][:protocol]})
        lprops.merge!({"InstanceProtocol" => listener[:listener][:instance_protocol]})
        lprops.merge!({"SSLCertificateId" => listener[:listener][:ssl_certificate_id].to_s}) if listener[:listener][:ssl_certificate_id]
        lprops.merge!({"PolicyNames"      => listener[:policy_names]}) if listener[:policy_names] and !listener[:policy_names].empty?
        listeners.push(lprops)
      end
      props.merge!({"Listeners" => listeners}) if !listeners.empty?
    end

    if resource[:policies]
      if resource[:policies][:app_cookie_stickiness_policies]
        policies = []
        resource[:policies][:app_cookie_stickiness_policies].each do |policy|
          policies.push({
            "PolicyName" => policy[:policy_name].to_s,
            "CookieName" => policy[:cookie_name].to_s
          })
        end
        props.merge!({"AppCookieStickinessPolicy" => policies}) if !policies.empty?
      end

      if resource[:policies][:lb_cookie_stickiness_policies]
        policies = []
        resource[:policies][:lb_cookie_stickiness_policies].each do |policy|
          policies.push({
            "PolicyName"             => policy[:policy_name].to_s,
            "CookieExpirationPeriod" => policy[:cookie_expiration_period].to_s
          })
        end
        props.merge!({"LBCookieStickinessPolicy" => policies}) if !policies.empty?
      end
    end

    return @cf_definition.deep_merge({ Elbs.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props }})
  end
    
end
