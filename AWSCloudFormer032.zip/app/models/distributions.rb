class Distributions < CF_converter
  
  attr_accessor :name
  
  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)
    begin
      # Get all the CloudFront distributions we care about
      cf = AWS::CloudFront.new()
      distributions = []
      cf.client.list_distributions().data[:items].each do |dist|
        dist_fixed = dist.clone
        dist_fixed.reject!{ |k| k == :last_modified_time }
        distributions << dist_fixed
      end
      all_resources.merge!({:distributions => distributions})
    rescue => e
      if region.eql?("us-gov-west-1")
        all_errors.merge!({:distributions => "Not supported in the GovCloud (US) region"})
      else
        all_errors.merge!({:distributions => e.message})
      end
      all_resources.merge!({:distributions => {}})
    end
  end
  
  def self.ResourceName(resource)
    return "dist" + resource[:domain_name].tr('^A-Za-z0-9', '')
  end
  
  def self.get_resource_attributes(resource)
    return "Comment: #{resource[:comment]} \n" +
           "Enabled: #{resource[:enabled]}"
  end
  
  def self.OutputList(resource)
    return {"Distribution Id" => "Name,Ref",
            "Domain Name" => "Domain,GetAtt,DomainName"}
  end

  def initialize(resource)
    @name = Distributions.ResourceName(resource)
    super(@name, "AWS::CloudFront::Distribution")
  end
  
  def convert(resource, template, name_mappings)
    props = {}
    props.merge!({"Comment" => resource[:comment]}) if resource[:comment]
    props.merge!({"Enabled" => resource[:enabled]}) if resource[:enabled]

    props.merge!({"Aliases" => resource[:aliases][:items]}) if resource[:aliases] and resource[:aliases][:items] and !resource[:aliases][:items].empty?

    cache_behaviors = []
    if resource[:cache_behaviors]
      resource[:cache_behaviors][:items].each do |cache|
        cache_behavior = {}
        cache_behavior.merge!({"TargetOriginId" => cache[:target_origin_id]}) if cache[:target_origin_id]
        cache_behavior.merge!({"PathPattern" => cache[:path_pattern]}) if cache[:path_pattern]
        cache_behavior.merge!({"ViewerProtocolPolicy" => cache[:viewer_protocol_policy]}) if cache[:viewer_protocol_policy]
        cache_behavior.merge!({"MinTTL" => cache[:min_ttl]}) if cache[:min_ttl]
        cache_behavior.merge!({"TrustedSigners" => cache[:trusted_signers][:items]}) if cache[:trusted_signers] and cache[:trusted_signers][:items] and !cache[:trusted_signers][:items].empty?
        if cache[:forwarded_values] and cache[:forwarded_values][:query_string]
          cache_behavior.merge!({"ForwardedValues" => {"QueryString" => cache[:forwarded_values][:query_string]} })
        end
        cache_behaviors << cache_behavior if !cache_behavior.empty?
      end
      props.merge!({"CacheBehaviors" => cache_behaviors}) if !cache_behaviors.empty?
    end
    
    if resource[:default_cache_behavior]
      default_cache_behavior = {}
      default_cache_behavior.merge!({"TargetOriginId" => resource[:default_cache_behavior][:target_origin_id]}) if resource[:default_cache_behavior][:target_origin_id]
      default_cache_behavior.merge!({"ViewerProtocolPolicy" => resource[:default_cache_behavior][:viewer_protocol_policy]}) if resource[:default_cache_behavior][:viewer_protocol_policy]
      default_cache_behavior.merge!({"MinTTL" => resource[:default_cache_behavior][:min_ttl]}) if resource[:default_cache_behavior][:min_ttl]
      default_cache_behavior.merge!({"TrustedSigners" => resource[:default_cache_behavior][:trusted_signers][:items]}) if resource[:default_cache_behavior][:trusted_signers] and resource[:default_cache_behavior][:trusted_signers][:items] and !resource[:default_cache_behavior][:trusted_signers][:items].empty?
      if resource[:default_cache_behavior][:forwarded_values] and resource[:default_cache_behavior][:forwarded_values][:query_string]
        default_cache_behavior.merge!({"ForwardedValues" => {"QueryString" => resource[:default_cache_behavior][:forwarded_values][:query_string]} })
      end
      props.merge!({"DefaultCacheBehavior" => default_cache_behavior}) if !default_cache_behavior.empty?
    end
    
    origins = []
    if resource[:origins]
      resource[:origins][:items].each do |origin|
        new_origin = {}
        new_origin.merge!({"DomainName" => origin[:domain_name]}) if origin[:domain_name]
        new_origin.merge!({"Id" => origin[:id]}) if origin[:id]
        if origin[:s3_origin_config]
          s3origin = {}
          s3origin.merge!({"OriginAccessIdentity" => origin[:s3_origin_config][:origin_access_identity]}) if origin[:s3_origin_config][:origin_access_identity]
          new_origin.merge!({"S3OriginConfig" => s3origin})
        elsif origin[:custom_origin_config]
          custom = {}
          custom.merge!({"HTTPPort" => origin[:custom_origin_config][:http_port].to_s}) if origin[:custom_origin_config][:http_port]
          custom.merge!({"HTTPSPort" => origin[:custom_origin_config][:https_port].to_s}) if origin[:custom_origin_config][:https_port]
          custom.merge!({"OriginProtocolPolicy" => origin[:custom_origin_config][:origin_protocol_policy]}) if origin[:custom_origin_config][:origin_protocol_policy]
          new_origin.merge!({"S3OriginConfig" => custom})
        end
        origins << new_origin if !new_origin.empty?
      end
      props.merge!({"Origins" => origins}) if !origins.empty?
    end

    return @cf_definition.deep_merge({ Distributions.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => {"DistributionConfig" => props }}})
  end
    
end
