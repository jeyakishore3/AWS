class Buckets < CF_converter
  
  attr_accessor :name
  
  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)

    region_endpoints = {
      nil => "s3.amazonaws.com",
      "us-east-1" => "s3.amazonaws.com",
      "EU" => "s3-eu-west-1.amazonaws.com",
      "eu-west-1" => "s3-eu-west-1.amazonaws.com",
      "eu-central-1" => "s3.eu-central-1.amazonaws.com",
      "us-west-1" => "s3-us-west-1.amazonaws.com",
      "us-west-2" => "s3-us-west-2.amazonaws.com",
      "ap-southeast-1" => "s3-ap-southeast-1.amazonaws.com",
      "ap-southeast-2" => "s3-ap-southeast-2.amazonaws.com",
      "ap-northeast-1" => "s3-ap-northeast-1.amazonaws.com",
      "sa-east-1" => "s3-sa-east-1.amazonaws.com",
      "cn-north-1" => "s3.cn-north-1.amazonaws.com.cn",
      "us-gov-west-1" => "s3-us-gov-west-1.amazonaws.com"
    }
    region_name = {
      nil => "us-east-1",
      "us-east-1" => "us-east-1",
      "EU" => "eu-west-1",
      "eu-west-1" => "eu-west-1",
      "eu-central-1" => "eu-central-1",
      "us-west-1" => "us-west-1",
      "us-west-2" => "us-west-2",
      "ap-southeast-1" => "ap-southeast-1",
      "ap-southeast-2" => "ap-southeast-2",
      "ap-northeast-1" => "ap-northeast-1",
      "sa-east-1" => "sa-east-1",
      "cn-north-1" => "cn-north-1",
      "us-gov-west-1" => "us-gov-west-1"
    }

    begin
      # Get all the S3 buckets we care about
      s3_global = AWS::S3.new(:s3_endpoint => region_endpoints[region])
      s3_buckets = []
      s3_global.client.list_buckets().data[:buckets].each do |bucket|
        # Flip to the specific endpoint for the bucket to retrieve info on the bucket
        begin
          bucket_location = s3_global.client.get_bucket_location(:bucket_name => bucket[:name]).data[:location_constraint]
          bucket_endpoint = region_endpoints[bucket_location]
          bucket_region = region_name[bucket_location]
        rescue
          bucket_region = "unknown"
        end
        if bucket_region == region
          s3 = AWS::S3.new(:s3_endpoint => bucket_endpoint)
          begin
            acls = s3.client.get_bucket_acl(:bucket_name => bucket[:name]).data
          rescue
            acls = []
          end
          begin
            tags = s3.client.get_bucket_tagging(:bucket_name => bucket[:name]).data
          rescue
            tags = []
          end
          begin
            webs = s3.client.get_bucket_website(:bucket_name => bucket[:name]).data
          rescue
            webs = []
          end
          s3_buckets.push({:name => bucket[:name], :display_name => "#{bucket[:name]} (#{bucket_region})", :permissions => acls, :tagging => tags, :website => webs})
        end
      end
      all_resources.merge!({:buckets => s3_buckets})
    rescue => e
      all_errors.merge!({:buckets => e.message})
      all_resources.merge!({:buckets => {}})
    end
  end
  
  def self.ResourceName(resource)
    return "s3" + resource[:name].tr('^A-Za-z0-9', '') 
  end

  def self.get_dependencies(resource, all_resources)
    bucket_policies = []
    if all_resources[:bucket_policies]
      all_resources[:bucket_policies].each do |policy|
        bucket_policies.push(policy) if resource[:name] == policy[:name]
      end      
    end
    return { :bucket_policies => bucket_policies }
  end
  
  def self.OutputList(resource)
    return {"Bucket Name"        => "Name,Ref",
            "Bucket Domain Name" => "URL,GetAtt,DomainName",
            "Bucket Website URL" => "WebURL,GetAtt,WebsiteURL"}
  end

  def initialize(resource)
    @name = Buckets.ResourceName(resource)
    super(@name, "AWS::S3::Bucket")
  end
  
  def convert(resource, template, name_mappings)
    props = {}

    website = {}
    if !resource[:website].empty?
      website.merge!({ "IndexDocument" => resource[:website][:index_document][:suffix] }) if resource[:website][:index_document] && resource[:website][:index_document][:suffix]
      website.merge!({ "ErrorDocument" => resource[:website][:error_document][:key] }) if resource[:website][:error_document] && resource[:website][:error_document][:key]
    end
    props.merge!({"WebsiteConfiguration" => website}) if !website.empty?      

    tags = []
    if !resource[:tagging].empty? && resource[:tagging][:tags]
      resource[:tagging][:tags].each do |key, value|
        tags.push({"Key" => key, "Value" => value}) if value != nil and !key.starts_with?("aws:")
      end
    end          
    props.merge!({"Tags" => tags}) if !tags.empty?      
    
    return @cf_definition.deep_merge({ Buckets.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props }})
  end
    
end
