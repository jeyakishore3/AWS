class Tables < CF_converter
  
  attr_accessor :name
  
  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)
    begin
      # Get all the DynamoDB tables we care about
      db = AWS::DynamoDB.new(:region => region)
      table_names = db.client.list_tables().data["TableNames"]
      tables = []
      if !table_names.empty?
        table_names.each do |tn|
          fixed_table = db.client.describe_table(:table_name => tn).data["Table"]
          fixed_table.reject!{ |k| k == "CreationDateTime" }
          fixed_table["ProvisionedThroughput"].reject!{ |k| k == "LastIncreaseDateTime" }
          fixed_table["ProvisionedThroughput"].reject!{ |k| k == "LastDecreaseDateTime" }
          tables << fixed_table
        end
        all_resources.merge!({:tables => tables})
      end
    rescue => e
      all_errors.merge!({:tables => e.message})
      all_resources.merge!({:tables => {}})
    end
  end
  
  def self.ResourceName(resource)
    return "table" + resource["TableName"].tr('^A-Za-z0-9', '') 
  end
  
  def self.OutputList(resource)
    return {"Table Name" => "Name,Ref"}
  end
  
  def initialize(resource)
    @name = Tables.ResourceName(resource)
    super(@name, "AWS::DynamoDB::Table")
  end
  
  def convert(resource, template, name_mappings)
    props = {}
    props.merge!({"KeySchema" => resource["KeySchema"]}) if resource["KeySchema"]
    if resource["ProvisionedThroughput"]
      throughput = {}
      resource["ProvisionedThroughput"].each do |key, value|
        throughput.merge!({key => value.to_s}) if key == "ReadCapacityUnits" || key == "WriteCapacityUnits"
      end
      props.merge!({"ProvisionedThroughput" => throughput})
    end
    return @cf_definition.deep_merge({ Tables.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props}}) 
  end
    
end
