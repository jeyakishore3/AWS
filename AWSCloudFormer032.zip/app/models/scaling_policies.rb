class Scaling_policies < CF_converter
  
  attr_accessor :name
  
  def self.LoadResources(all_resources, aws_access_key_id, aws_secret_access_key, region, all_errors)
    begin
      # Get all the Auto Scaling policies we care about
      as = AWS::AutoScaling.new(:region => region)
      all_resources.merge!({:scaling_policies => as.client.describe_policies().data[:scaling_policies]})
    rescue => e
      all_errors.merge!({:scaling_policies => e.message})
      all_resources.merge!({:scaling_policies => {}})
    end
  end
  
  def self.ResourceName(resource)
    return "scaling" + resource[:policy_name].tr('^A-Za-z0-9', '')
  end
  
  def self.get_dependencies(resource, all_resources)
    return {}
  end
  
  def self.get_resource_attributes(resource)
    return "PolicyName: #{resource[:policy_name]} \n" +
           "AdjustmentType: #{resource[:adjustment_type]} \n" +
           "ScalingAdjustment: #{resource[:scaling_adjustment]}"
  end

  def self.OutputList(resource)
    return {"Scaling Policy Name" => "Name,Ref"}
  end

  def initialize(resource)
    @name = Scaling_policies.ResourceName(resource)
    super(@name, "AWS::AutoScaling::ScalingPolicy")
  end
  
  def convert(resource, template, name_mappings)
    props = {}
    props.merge!({"AdjustmentType" => resource[:adjustment_type]}) if resource[:adjustment_type]
    props.merge!({"Cooldown" => resource[:cooldown].to_s}) if resource[:cooldown]
    props.merge!({"ScalingAdjustment" => resource[:scaling_adjustment].to_s}) if resource[:scaling_adjustment] 

    props.merge!({"AutoScalingGroupName" => ref_or_literal(:as_groups, resource[:auto_scaling_group_name], template, name_mappings)}) if resource[:auto_scaling_group_name]

    return @cf_definition.deep_merge({ Scaling_policies.map_resource_name(@name, name_mappings) => { "Type" => @cf_type, "Properties" => props }})
  end
    
end
